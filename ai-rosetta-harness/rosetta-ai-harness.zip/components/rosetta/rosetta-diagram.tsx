"use client"

import { useCallback, useEffect } from "react"
import { ReactFlow, ReactFlowProvider, useReactFlow, type Node } from "@xyflow/react"
import "@xyflow/react/dist/style.css"
import { nodeTypes } from "./nodes"
import { CATEGORY, type Category } from "./primitives"
import { edgeTypes, type FlowEdge } from "./flow-edge"

/** vertical space reserved for the header so the graph never sits under it */
const HEADER_OFFSET = 128

const nodes: Node[] = [
  { id: "orb", type: "orb", position: { x: 815, y: 345 }, data: {} },
  { id: "renderer", type: "renderer", position: { x: 450, y: 20 }, data: {} },
  { id: "providers", type: "providers", position: { x: 1440, y: 165 }, data: {} },
  { id: "skills", type: "skills", position: { x: 1475, y: 430 }, data: {} },
  { id: "connected", type: "connected", position: { x: 1380, y: 700 }, data: {} },
  { id: "mcp", type: "mcp", position: { x: 710, y: 735 }, data: {} },
  { id: "tools", type: "tools", position: { x: 20, y: 660 }, data: {} },
  { id: "memory", type: "memory", position: { x: 20, y: 385 }, data: {} },
]

const spokes: Category[] = ["renderer", "providers", "skills", "connected", "mcp", "tools", "memory"]

const edges: FlowEdge[] = spokes.map((cat, i) => ({
  id: `orb-${cat}`,
  source: "orb",
  sourceHandle: cat,
  target: cat,
  targetHandle: "in",
  type: "flow",
  // stagger each spoke so the traveling packets and pulses feel orchestrated
  data: { category: cat, delay: (i * 0.4) % 2.8 },
}))

function Defs() {
  return (
    <svg width="0" height="0" style={{ position: "absolute" }} aria-hidden>
      <defs>
        {spokes.map((cat) => {
          const [a, b] = CATEGORY[cat].grad
          return (
            <linearGradient key={cat} id={`g-${cat}`} x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor={a} />
              <stop offset="100%" stopColor={b} />
            </linearGradient>
          )
        })}
      </defs>
    </svg>
  )
}

function Canvas() {
  const { fitView } = useReactFlow()
  const refit = useCallback(() => fitView({ padding: 0.06, duration: 0 }), [fitView])

  useEffect(() => {
    const onResize = () => refit()
    window.addEventListener("resize", onResize)
    return () => window.removeEventListener("resize", onResize)
  }, [refit])

  return (
    <ReactFlow
      nodes={nodes}
      edges={edges}
      nodeTypes={nodeTypes}
      edgeTypes={edgeTypes}
      fitView
      fitViewOptions={{ padding: 0.06 }}
      minZoom={0.1}
      maxZoom={2}
      nodesDraggable={false}
      nodesConnectable={false}
      nodesFocusable={false}
      edgesFocusable={false}
      elementsSelectable={false}
      panOnDrag={false}
      panOnScroll={false}
      zoomOnScroll={false}
      zoomOnPinch={false}
      zoomOnDoubleClick={false}
      preventScrolling={false}
      proOptions={{ hideAttribution: true }}
      onInit={() => refit()}
    />
  )
}

export function RosettaDiagram() {
  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        height: "100dvh",
        overflow: "hidden",
        background:
          "radial-gradient(circle at top left, rgba(249,115,22,0.10), transparent 28%)," +
          "radial-gradient(circle at top right, rgba(59,130,246,0.08), transparent 30%)," +
          "radial-gradient(circle at bottom center, rgba(236,72,153,0.07), transparent 36%)," +
          "linear-gradient(180deg, #fefbf7 0%, #f8fafc 50%, #eef2ff 100%)",
      }}
    >
      <style>{`
        .rosetta-rings .rosetta-ring{position:absolute;border-radius:50%;border:1.5px solid transparent;transform-origin:center}
        .rosetta-rings .r1{inset:-24px;border-top-color:rgba(124,58,237,0.55);border-right-color:rgba(236,72,153,0.35);border-bottom-color:rgba(245,158,11,0.45);border-left-color:rgba(59,130,246,0.4);animation:rosetta-spin 18s linear infinite}
        .rosetta-rings .r2{inset:-48px;border-top-color:rgba(59,130,246,0.45);border-left-color:rgba(16,185,129,0.4);border-bottom-color:rgba(236,72,153,0.3);animation:rosetta-spin 26s linear infinite reverse}
        .rosetta-rings .r3{inset:-76px;border-top-color:rgba(236,72,153,0.35);border-right-color:rgba(245,158,11,0.35);opacity:.8;animation:rosetta-spin 36s linear infinite}
        @keyframes rosetta-spin{to{transform:rotate(360deg)}}
        @keyframes rosetta-dash{to{stroke-dashoffset:-32}}
        .react-flow__renderer,.react-flow__pane{cursor:default!important}
        .react-flow__handle{opacity:1!important}
        .react-flow__edge{pointer-events:none}
      `}</style>

      <Defs />

      {/* Header */}
      <header
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          zIndex: 10,
          display: "flex",
          alignItems: "flex-start",
          justifyContent: "space-between",
          gap: 14,
          padding: "16px 22px 0",
          pointerEvents: "none",
        }}
      >
        <div style={{ minWidth: 0 }}>
          <p
            style={{
              fontSize: 10,
              fontWeight: 800,
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              color: "#b45309",
              margin: 0,
            }}
          >
            Electron Application Architecture · DBT Studio
          </p>
          <h1 style={{ fontSize: 38, fontWeight: 900, letterSpacing: "-0.045em", lineHeight: 0.95, margin: "2px 0 0" }}>
            <span
              style={{
                background: "linear-gradient(135deg, #ea580c 0%, #d97706 50%, #ca8a04 100%)",
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              Rosetta AI
            </span>{" "}
            Harness Stack
          </h1>
          <p style={{ marginTop: 4, fontSize: 12, color: "#475569", fontWeight: 500, maxWidth: 620 }}>
            A hub-and-spoke stack map for AI-assisted data engineering inside DBT Studio — the AI Agent orchestrates
            every layer from UI to data lake.
          </p>
        </div>
        <a
          href="https://rosettalabs.ai/"
          target="_blank"
          rel="noopener noreferrer"
          style={{
            pointerEvents: "auto",
            flexShrink: 0,
            display: "flex",
            alignItems: "center",
            gap: 8,
            padding: "5px 12px 5px 5px",
            borderRadius: 999,
            background: "rgba(255,255,255,0.9)",
            border: "1px solid rgba(148,163,184,0.2)",
            boxShadow: "0 6px 20px rgba(15,23,42,0.07), inset 0 1px 0 rgba(255,255,255,0.9)",
            backdropFilter: "blur(10px)",
            textDecoration: "none",
          }}
        >
          <span
            style={{
              width: 32,
              height: 32,
              borderRadius: "50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <img src="/assets/icons/rosetta-labs.svg" alt="Rosetta Labs" style={{ width: 32, height: 32 }} />
          </span>
          <span style={{ display: "flex", flexDirection: "column" }}>
            <span style={{ fontSize: 12, fontWeight: 800, color: "#1e293b", lineHeight: 1.05 }}>Rosetta Studio</span>
            <span style={{ fontSize: 10, color: "#475569", fontWeight: 600, marginTop: 1 }}>rosettalabs.ai</span>
          </span>
        </a>
      </header>

      {/* Flow area is inset below the header so fitView frames the graph in the
          space beneath the title and the top card never collides with it. */}
      <div style={{ position: "absolute", top: HEADER_OFFSET, left: 0, right: 0, bottom: 0 }}>
        <ReactFlowProvider>
          <Canvas />
        </ReactFlowProvider>
      </div>
    </div>
  )
}
